# -*- coding utf-8 -*-#
# ------------------------------------------------------------------
# Name:      test1
# Author:    liangbaikai
# Date:      2019/12/25
# Desc:      there is a python file description
# ------------------------------------------------------------------

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument('--disable-gpu')
chrome_options.add_argument('--disable-dev-shm-usage')
driver = webdriver.Chrome(executable_path=(r'/usr/bin/chromedriver'), chrome_options=chrome_options)
driver.get('https://www.baidu.com')
print(driver.title)
print('测试linux chrome driver xvfb selenium等环境成功')
driver.quit()